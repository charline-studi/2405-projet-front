import { Home } from "./modules/Home.js"

new Home()